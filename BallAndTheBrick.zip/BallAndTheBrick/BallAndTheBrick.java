//Islam Shehata CS 214
import java.awt.event.KeyEvent;
public class BallAndTheBrick
{
    public static void main(String[] args)
    {
        //ball
        double ballx = 0.1;
        double bally = 0.1;
        double ballSize = 0.02;
        double ballxVel = 0.03;
        double ballyVel = 0.03;
        
        //paddle
        double paddleX = 0.5;
        double paddleY = 0;
        double paddleHeight = 0.02;
        double paddleWidth = 0.1;
        
        //background
        double backgroundX = 1;
        double backgroundY = 1;
        double backgroundSize = 1;
       
        // array of bricks
        double[] brickwallX =      { 0.09 , 0.1  , 0.3  , 0.5  , 0.7  , 0.9  , 0.09 , 0.1  , 0.3  , 0.5   , 0.7  , 0.9  , 0.09 , 0.1  , 0.3  , 0.5  , 0.7  , 0.9  , 0.09 , 0.1  , 0.3  , 0.5  , 0.7  , 0.9  };
        double[] brickwallY =      { 0.75 , 0.75 , 0.75 , 0.75 , 0.75 , 0.75 , 0.8  , 0.8  , 0.8  , 0.8   , 0.8  , 0.8  , 0.85 , 0.85 , 0.85 , 0.85 , 0.85 , 0.85 , 0.9  , 0.9  , 0.9  , 0.9  , 0.9  , 0.9  };
        double   brickwallHeight =   0.02 ;
        double   brickwallWidth =    0.09 ;
        
        //collision booleans
        boolean[] collision = {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false};
        
        while (true)
        {
            StdDraw.clear();
            
            ballx +=  ballxVel;
            bally +=  ballyVel;
            
            //ball speed
            if(ballx < 0)
            {
                ballxVel = 0.025;
            }
            if(ballx > 1)
            {
                ballxVel = -0.025;
            }
            if(bally > 1)
            {
                ballyVel = -0.025;
            }
            
            //background color
            StdDraw.picture(backgroundX, backgroundY, "solid-baby-blue.jpg");
            
            //ball color
            StdDraw.setPenColor(StdDraw.GREEN);
            StdDraw.filledCircle(ballx, bally, ballSize);
            
            // paddle color
            StdDraw.setPenColor(StdDraw.BLACK);
            StdDraw.filledRectangle(paddleX, paddleY, paddleWidth, paddleHeight);
            
            //bricks
            for (int x = 0 ; x < brickwallX.length ; x++)
            {
                if (!collision[x])
                {
                    StdDraw.setPenColor(StdDraw.RED);
                    StdDraw.filledRectangle( brickwallX[x], brickwallY[x] , brickwallWidth , brickwallHeight);
                }
                
                double brickbottom = brickwallY[x] - brickwallHeight;
                double circle      = bally + ballSize;
                
                if ( brickwallY[x] - brickwallHeight < bally + ballSize && 
                
                ballx > brickwallX[x] - brickwallWidth &&
                
                ballx < brickwallX[x] + brickwallWidth && !collision[x])
                {
                    ballyVel *= -1;
                    collision[x] = true;
                }              
            }
            
            //paddle movement
            if(StdDraw.isKeyPressed(KeyEvent.VK_LEFT))
            {
                paddleX -= 0.03;   
            }
            else if(StdDraw.isKeyPressed(KeyEvent.VK_RIGHT))
            {
                paddleX += 0.03;   
            }
            
            //paddle circulared
            if (paddleX < -0.25)
            {
                paddleX = 1.25;
            }
            if (paddleX > 1.25)
            {
                paddleX = -0.25;
            }
            
            // once ball hitting the paddle
            if (paddleY + paddleHeight > bally - ballSize && 
                
                ballx > paddleX - paddleWidth &&
                
                ballx < paddleX + paddleWidth )
            {
                ballyVel *= -1;
                
            }
            //Finish Line
            StdDraw.setPenColor(StdDraw.WHITE);
            StdDraw.text(0.5,0.95,"FINISH LINE");
            StdDraw.show();
            
            // when ball reaches the finish line :)
            if (bally > 1)
            {
                StdDraw.setPenColor(StdDraw.WHITE);
                StdDraw.text(0.5,0.5,"You WIN!" );
                StdDraw.show();
                break;
            }
            // when ball goes below the paddle :(  
            else if (bally <= 0)
            {
                StdDraw.setPenColor(StdDraw.WHITE);
                StdDraw.text(0.5,0.5,"You LOSE!");
                StdDraw.show();
                break;
            }
            
            StdDraw.show(1000/60); 
        }
    }
}