/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment1.pkg2.pkg2;

/**
 *
 * @author ias105
 */
//Assignment (2-1)
public class Assignment122 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("Assignment1 Question (2-1)");
        
        int input1A = 0;
        int input1B = 0;
        int input1C = 0;
        
        int input2A = 1;
        int input2B = 0;
        int input2C = 0;
        
        int input3A = 0;
        int input3B = 1;
        int input3C = 0;
        
        int input4A = 1;
        int input4B = 1;
        int input4C = 0;
        
        int input5A = 0;
        int input5B = 0;
        int input5C = 1;
        
        int input6A = 1;
        int input6B = 0;
        int input6C = 1;
        
        int input7A = 0;
        int input7B = 1;
        int input7C = 1;
        
        int input8A = 1;
        int input8B = 1;
        int input8C = 1;
        
        int TargetOutout1 = 1;
        int TargetOutout2 = 1;
        int TargetOutout3 = 0;
        int TargetOutout4 = 0;
        int TargetOutout5 = 1;
        int TargetOutout6 = 1;
        int TargetOutout7 = 0;
        int TargetOutout8 = 0;
        
        
        double LC = 0.4;
        
        double T = -1.0;
        
        double w1 = 0.5;
        double w2 = 0.7;
        double w3 = 0.8;
        
        System.out.println("For input (0,0,0)");
        double FirstOperation = (input1A * w1) + (input1B * w2) + (input1C * w3);
        System.out.println("Result: "+ FirstOperation);
        System.out.println("New weight of 0.5: 0.5 + 0.4 *(1-1)*0 = 0.5 No change");
        System.out.println("New weight of 0.7: 0.7 + 0.4 *(1-1)*0 = 0.7 No change");
        System.out.println("New weight of 0.8: 0.8 + 0.4 *(1-1)*0 = 0.8 No change");
        System.out.println("Actual output is 1, because result is 0 and 0 > -1.0. No change");
        System.out.println(" ");
        
        System.out.println("For input (1,0,0)");
        double SecondOperation = (input2A * w1) + (input2B * w2) + (input2C * w3);
        System.out.print("result: " + SecondOperation);
        System.out.println("New weight of 0.5: 0.5 + 0.4 *(1-1)*1 = 0.5 No change");
        System.out.println("New weight of 0.7: 0.7 + 0.4 *(1-1)*0 = 0.7 No change");
        System.out.println("New weight of 0.8: 0.8 + 0.4 *(1-1)*0 = 0.8 No change");
        System.out.println("Actual output is 1, because result is 0 and 0 > -1.0. No change");
        System.out.println(" ");
        
        System.out.println("For input (0,1,0)");
        double ThirdOperation = (input3A * w1) + (input3B * w2) + (input3C * w3);
        System.out.print("result: " + ThirdOperation);
        System.out.println("New weight of 0.5: 0.5 + 0.4 *(0-1)*0 = 0.5 No change");
        System.out.println("First Epoch");
        System.out.println("New weight of 0.7: 0.7 + 0.4 *(0-1)*1 = 0.3 ");
        System.out.println(" ");
        
        System.out.println("Second Epoch");
        System.out.println("New weight of 0.3: 0.3 + 0.4 *(0-1)*1 = -0.1");
        System.out.println(" ");
        
        System.out.println("Third Epoch");
        System.out.println("New weight of -0.1: 0.3 + 0.4 *(0-1)*1 = -0.5");
        System.out.println(" ");
        
        System.out.println("Fourth Epoch");
        System.out.println("New weight of -0.5: 0.3 + 0.4 *(0-1)*1 = -0.9");
        System.out.println(" ");
        
        System.out.println("Fifth Epoch");
        System.out.println("New weight of -0.9: 0.3 + 0.4 *(0-1)*1 = -1.3");
        System.out.println(" ");
        
        System.out.println("New weight of 0.8: 0.8 + 0.4 *(0-1)*0 = 0.8 No change");
        System.out.println("Actual output is 1, because result is 0 and 0 > -1.0. Does not match Target output, change is needed");
        System.out.println("New weights (0.5, -1.3, 0.8)");
        System.out.println(" ");
        
        
        
        System.out.println("For input (1,1,0)");
        double FourthOperation = (input4A * w1) + (input4B * -1.3) + (input4C * w3);
        System.out.print("result: " + FourthOperation);
        
        System.out.println("First Epoch");
        System.out.println("New weight of 0.5: 0.5 + 0.4 *(0-1)*1 = 0.1 ");
        System.out.println("New weight of -1.3: -1.3 + 0.4 *(0-1)*1 = -0.1 ");
        System.out.println(" ");
        
        System.out.println("Second Epoch");
        System.out.println("New weight of 0.1: 0.1 + 0.4 *(0-1)*1 = -0.3 ");
        System.out.println("New weight of 0.3: 0.3 + 0.4 *(0-1)*1 = -0.5 ");
        System.out.println(" ");
        
        System.out.println("Third Epoch");
        System.out.println("New weight of -0.3: -0.3 + 0.4 *(0-1)*1 = -0.7 ");
        System.out.println("New weight of -0.5: -0.5 + 0.4 *(0-1)*1 = -0.9 ");
        System.out.println(" ");
        
        
        System.out.println("New weight of 0.8: 0.8 + 0.4 *(0-1)*0 = 0.8 No change");
        System.out.println("Actual output is 1, because result is 0 and 0 > -1.0. No change");
        System.out.println(" ");
        
        System.out.println("After 3rd epoch result = -1.6 < -1.0.  New actual output is 0 which ='s to inital target output");
        System.out.println("New Weights (-0.7, -0.9, 0.8");
        System.out.println(" ");
        
        System.out.println("For input (0,0,1)");
        double FifthOperation = (input5A * -0.7) + (input5B * -0.9) + (input5C * w3);
        System.out.println("result: " + FourthOperation);
        System.out.println("Actual output is 1, because result is -0.8 and -0.8 > -1.0. Actual output does match Target output, no change is needed");
        
        System.out.println("New weight of -0.7: -0.7 + 0.4 *(1-1)*0 = -0.7  No change");
        System.out.println("New weight of -0.9: -0.9 + 0.4 *(1-1)*0 = -0.9  No change");
        System.out.println("New weight of 0.8: 0.8 + 0.4 *(1-1)*1 = 0.8 No change");
        System.out.println(" ");
        
        System.out.println("For input (1,0,1)");
        double SixthOperation = (input6A * -0.7) + (input6B * -0.9) + (input6C * w3);
        System.out.printf("result: %.1f ", SixthOperation);
        System.out.println("\nActual output is 1, because result is 0.1 and 0.1 > -1.0. Actual output does match Target output, no change is needed");
        
        System.out.println("New weight of -0.7: -0.7 + 0.4 *(1-1)*1 = -0.7  No change");
        System.out.println("New weight of -0.9: -0.9 + 0.4 *(1-1)*0 = -0.9  No change");
        System.out.println("New weight of 0.8: 0.8 + 0.4 *(1-1)*1 = 0.8 No change");
        System.out.println(" ");
        
        
        System.out.println("For input (0,1,1)");
        double SeventhOperation = (input7A * -0.7) + (input7B * -0.9) + (input7C * w3);
        System.out.printf("result: %.1f" , SeventhOperation);
        System.out.println("\nActual output is 1, because result is -0.1 and 0.1 > -1.0. Actual output does not match Target output, change is needed");
        System.out.println(" ");
        
        
        System.out.println("First Epoch");
        System.out.println("New weight of -0.7: -0.7 + 0.4 *(0-1)*0 = -0.7 No change");
        System.out.println("New weight of -0.9: -0.9 + 0.4 *(0-1)*1 = -1.3 ");
        System.out.println("New weight of 0.8: 0.8 + 0.4 *(0-1)*1 = 0.4");
        System.out.println(" ");
 
        System.out.println("Second Epoch");
        System.out.println("New weight of -0.7: -0.7 + 0.4 *(0-1)*0 = -0.7 No change");
        System.out.println("New weight of -1.3: -1.3 + 0.4 *(0-1)*1 = -1.7 ");
        System.out.println("New weight of 0.4: 0.4 + 0.4 *(0-1)*1 = 0.0");
        System.out.println(" ");
        
        System.out.println("After 2rd epoch result = -1.7 < -1.0.  New actual output is 0 which ='s to inital target output");
        System.out.println("New Weights (-0.7, -1.7, 0.0)");
        System.out.println(" ");
        
        System.out.println("For input (1,1,1)");
        double EightOperation = (input8A * -0.7) + (input8B * -1.7) + (input8C * 0.0);
        System.out.printf("result: %.1f" , EightOperation);
        System.out.println("\nActual output is 0, because result is -2.4 and -2.4 < -1.0. Actual output does match Target output, No change is needed");
        System.out.println("Final weights (-0.7, -1.7, 0.0)");
        System.out.println(" ");
        
        
    }
    
}
