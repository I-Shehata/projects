/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment1;

/**
 *
 * @author ias105
 */
// OR Operation
public class Assignment1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int input1A = 0;
        int input1B = 0;
        
        int input2A = 0;
        int input2B = 1;
        
        int input3A = 1;
        int input3B = 0;
        
        int input4A = 1;
        int input4B = 1;
        
        int Targetoutput1 = 1;
        int Targetoutput2 = 0;
        int Targetoutput3 = 0;
        int Targetoutput4 = 0;
        
        double LC = 0.6;
        double T  = -1.0;
        
        double w1 = 0.7;
        double w2 = 0.3;
        
        System.out.println("First Epoch");
        System.out.println("");
        
        //(0,0)
        System.out.println("For input units (0,0)");
        double firstOperation = (input1A * w1) + (input1B * w2);
        System.out.println("0*0.7 + 0*0.3 = 0 ");
        System.out.println("Actual output of (0,0) = 1. " + firstOperation + " Threshold is -1.0. Actual output is 1 (no change)");
        
        double a = w1 + LC * (Targetoutput1 - 1)* 0;
        System.out.print("New weight for 0.7:   ");
        System.out.println("0.7 + 0.6 * (1 - 1)* 0 = " + a);
        
        double b = w2 + LC * (Targetoutput1 - 1)* 0;
        System.out.print("New weight for 0.3:   ");
        System.out.println("0.3 + 0.6 * (1 - 1)* 0 = " + b);
        System.out.println(" ");
        
        
        //(0,1)
        System.out.println("For input units (0,1)");
        double SecondOperation = (input2A * a) + (input2B * b);
        System.out.println("0*0.7 + 1*0.3 = 0.3 ");
        System.out.println("Actual output of (0,1) = 1. " + SecondOperation + " Threshold is -1.0. Actual output is 1 becuase 0.3 > -1.0\n");
        
        double c = a + LC *(Targetoutput2 - 1)*0;
        System.out.print("New weight for 0.7: ");
        System.out.println("0.7 + 0.6 * (0 - 1)* 0 = " + c + " no change since input is 0");
        
        double d = b + LC *(Targetoutput2 - 1)*1;
        System.out.print("New weight for 0.3: ");
        System.out.println("0.3 + 0.6 * (0 - 1)* 1 = " + d);
        System.out.println(" ");
        
        //(1,0)
        System.out.println("For input units (1,0)");
        double ThirdOperation = (input3A * c) + (input3B * d);
        System.out.println("1*0.7 + 0*-0.3 = 0.7");
        System.out.println("Actual output of (1,0) = 1. " + ThirdOperation + " Threshold is -1.0. Actual output is 1 becuase 0.7 > -1.0\n");
        
        double e =  c + LC *(Targetoutput3 - 1)*1;
        System.out.print("New weight for 0.7: ");
        System.out.print("-0.7 + 0.6 *(0-1)*1 =  ");
        System.out.printf("%.1f\n", e);
        
        double f = d + LC * (Targetoutput3 - 1)*0;
        System.out.println("New weight for -0.3: " + f + " no change since input in 0");
        System.out.print("-0.3+ 0.6*(0-1)*1 = ");
        System.out.printf("%.1f\n", f);
        System.out.println(" ");
        
        //(1,1)
        System.out.println("For input units (1,1)");
        double FourthOperation = (input4A * e) + (input4B *f);
        System.out.println("1*0.1 + 1 *-0.3 = -0.2");
        System.out.println("Actual output of (1,1) = 1. " + FourthOperation + " Threshold is -1.0. Actual output is 1 becuase -0.2 > -1.0\n");
        
        double g = e + LC *(Targetoutput4 - 1 )*1;
        System.out.print("New weight for 0.1: ");
        System.out.print("0.1 + 0.6*(0-1)*1 = ");
        System.out.printf("%.1f\n", g);
        
        double h = f + LC * (Targetoutput4 - 1)*1;
        System.out.print("New weight for -0.3: ");
        System.out.print("-0.3 + 0.6*(0-1)*1 = ");
        System.out.printf("%.1f", h);
        
        System.out.println(" ");
        System.out.println(" ");
        
        System.out.println("Second Epoch");
        System.out.println(" ");
        
        //(0,0)
        System.out.println("For input units (0,0)");
        double FifthOperation = (input1A * g) + (input1B * h);
        System.out.println("0*-0.5 + 0* -0.9 = 0");
        System.out.println("Actual output of (0,0) = 1. " + FifthOperation + " Threshold is -1.0. Actual output is 1, mathces target output (no change)");
        System.out.println(" ");
        
        //(0,1)
        System.out.println("For input units (0,1)");
        double SixthOperation = (input2A * g) + (input2B * h);
        System.out.print("0*-0.5 + 1 * -0.9 = ");
        System.out.printf("%.1f Actual output of (0,1) = 1. Threshold is -1.0. Actual output is 1 becuase -0.9 > -1.0\n", SixthOperation);
        double i = g + LC * (Targetoutput2 - 1)*0;
        System.out.println("New weight for -0.5: " + i + " no change since input in 0");
        
        
        double j = h + LC *(Targetoutput2 - 1)*1;
        System.out.print("New weight for -0.9: ");
        System.out.println("-0.9 + 0.6 * (0 - 1)* 1 = " + j);
        System.out.println(" ");
        
        //(1,0)
        System.out.println("For input units (1,0)");
        double SeventhOperation = (input3A *i) + (input3B *j);
        System.out.println("1*-0.5 + 0*-1.5 = " + SeventhOperation);
        System.out.println("Actual output of (1,0) = 1. " + SeventhOperation + " Threshold is -1.0. Actual output is 1 because -0.5 > -1.0");
        
        double k = i + LC * (Targetoutput3 - 1)*1;
        System.out.print("New weight for -0.5: ");
        System.out.println("-0.5 + 0.6 *(0-1)*1 = " + k);
        
        double l = j + LC * (Targetoutput3 -1)*0;
        System.out.print("New weight for -1.5: ");   
        System.out.println("-1.5 + 0.6*(0-1)*0 = " + l + " no change since input is 0");
         System.out.println("weights are (-0.5, -1.5)");
        System.out.println(" ");
        
        //(1,1)
        System.out.println("For input units (1,1)");
        double EightOperation = (input4A * k) + (input4B *l);
        System.out.println("1*-1.1 + 1*-1.5 = "+EightOperation);
        System.out.println("Actual output of (1,1) = 0. " + EightOperation + " Threshold is -1.0. Actual output is 0 becuase -2.6 < -1.0 no change");
        System.out.println("weights are (-1.1, -1.5)");
        System.out.println(" ");
        System.out.println(" ");
        
        System.out.println("Third Epoch");
        System.out.println(" ");
        
        //(0,0)
        System.out.println("For input units (0,0)");
        double NinethOperation = (input1A * k) + (input1B * l);
        System.out.println("0*-1.1 + 0*-1.5 = " + NinethOperation);
        System.out.println("Actual output of (0,0) = 1. " + NinethOperation + " Threshold is -1.0. Actual output is 1, mathces target output (no change)");
        System.out.println("weights are (-1.1, -1.5)");
        System.out.println(" ");
        
        //(0,1)
        System.out.println("For input units (0,1)");
        double tenthOperation = (input2A * k) + (input2B * l);
        System.out.println("0*-1.1 + 1*-1.5= " +tenthOperation);
        System.out.println("Actual output of (1,1) = 0. " + tenthOperation + " Threshold is -1.0. Actual output is 0 becuase -1.5 < -1.0 no change");
        System.out.println("weights are (-1.1, -1.5)");
        System.out.println(" ");
        
        
        //(1,0)
        System.out.println("For input units (1,0)");
        double eleventhOperation = (input3A * k)+(input3B *l );
        System.out.println("1*-1.1 + 0*-1.5= " +eleventhOperation);
        System.out.println("Actual output of (1,1) = 0. " + eleventhOperation + " Threshold is -1.0. Actual output is 0 becuase -1.1 < -1.0 no change");
        System.out.println("weights are (-1.1, -1.5)");
        System.out.println(" ");
        
        //(1,1)
        System.out.println("For input units (1,1)");
        double TwelevethOperation = (input4A * k)+(input4B *l );
        System.out.println("1*-1.1 + 1*-1.5= " +TwelevethOperation);
        System.out.println("Actual output of (1,1) = 0. " + eleventhOperation + " Threshold is -1.0. Actual output is 0 becuase -2.6 < -1.0 no change");
        System.out.println("weights are (-1.1, -1.5)");
        System.out.println(" ");
        
        System.out.println(" ");
    }
    
}
