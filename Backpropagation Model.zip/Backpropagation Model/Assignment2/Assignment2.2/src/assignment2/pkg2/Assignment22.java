/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2.pkg2;

/**
 *
 * @author THE ias105
 */
public class Assignment22 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("Sigmoid function");
        System.out.println("");
        System.out.println("Input (1,1) target output (1) results:");
        System.out.println("Simlating using 2 inputs, 2 hidden units, and 1 output unit");
        System.out.println("");
        System.out.println("Hidden units");
        
        int inputOne = 0;
        int inputTwo = 0;
        
        int inputOneOne = 0;
        int inputOneTwo = 0;
        int targetOutputOne = 1;
        
        int inputTwoOne = 0;
        int inputTwoTwo = 1;
        int targetOutputTwo = 0;
        
        int inputThreeOne = 1;
        int inputThreeTwo = 0;
        int targetOutputThree = 0;
        
        int inputFourOne = 1;
        int inputFourTwo = 1;
        int targetOutputFour = 1;
        
        double oneToOne = 0.1;
        double oneToTwo = 0.3;
        double twoToOne = 0.2;
        double twoToTwo = 0.4;
        
        double hiddenOneToOne = 0.5;
        double hiddenTwoToOne = 0.6;
        
        double learningCoeff = 0.7;
        System.out.println("");
        
        double resultOne = inputOneOne*oneToOne + inputOneTwo*twoToOne;
        System.out.println("Net_Hidden_unit_1: 0*0.1 + 0*0.2 = " + resultOne );
        
        double resultTwo = inputOneOne*oneToTwo + inputOneTwo*twoToTwo;
        System.out.println("Net_Hidden_unit_2: 0*0.3 + 0*0.4 = " + resultTwo );
        System.out.println("");
        
        //using sigmoid method
        double OutputHiddenUnitOne = 1/(1 + Math.exp(-0));
        System.out.println("Output_of_hidden_unit_1: 1/(1+e^-(0)) = " + OutputHiddenUnitOne);
        
        //using sigmoid method
        double OutputHiddenUnitTwo = 1/(1 + Math.exp(-0));
        System.out.println("Output_of_hidden_unit_2: 1/(1+e^-(0)) = " + OutputHiddenUnitTwo);
        System.out.println("");
        
        double netWeight = OutputHiddenUnitOne * hiddenOneToOne + OutputHiddenUnitTwo * hiddenTwoToOne;
        System.out.println("Net_of_Output_unit_1: " + netWeight);
        System.out.println("");
        
        //using sigmoid method
        double ActualOutputUnitOne = 1/(1 + Math.exp(-netWeight));
        System.out.printf("Actual_Output_of_Output_unit_1: 1/(1+e^(0.55)) = %.4f" , ActualOutputUnitOne);
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        
        System.out.println("New weights between hidden layer and output layer");
        System.out.println("");
        
        double deltaOutputUnitOne = (1 - ActualOutputUnitOne) * ActualOutputUnitOne * (1-ActualOutputUnitOne);
        System.out.printf("Delta_of_output_unit_1 = %.4f" , deltaOutputUnitOne);
        System.out.println("");
        
        System.out.println("Updated weights");
        
        double UpdatedWeightOne = hiddenOneToOne + learningCoeff * (deltaOutputUnitOne) * OutputHiddenUnitOne;
        System.out.printf("New weights for 0.5 = %.4f" , UpdatedWeightOne);
        System.out.println("");
        
        double UpdatedWeightTwo = hiddenTwoToOne + learningCoeff * (deltaOutputUnitOne) * OutputHiddenUnitTwo;
        System.out.printf("New weights for 0.6 = %.4f" , UpdatedWeightTwo);
        System.out.println("");
        System.out.println("");
        
        System.out.println("New weights between input and hidden layers");
        System.out.println("");
        
        double deltaHiddenOne = deltaOutputUnitOne * hiddenOneToOne * OutputHiddenUnitOne * (1 - OutputHiddenUnitOne);
        System.out.printf("Delta_hidden_unit_1 = %.4f " , deltaHiddenOne);
        System.out.println("");
        
        double deltaHiddenTwo = deltaOutputUnitOne * hiddenTwoToOne * OutputHiddenUnitTwo * (1 - OutputHiddenUnitTwo);
        System.out.printf("Delta_hidden_unit_1 = %.4f " , deltaHiddenTwo);
        System.out.println("");
        System.out.println("");
        
        
        double newWeightOne = oneToOne + learningCoeff * deltaHiddenOne * inputOne;
        System.out.printf("New Weights of 0.1: %.4f " , newWeightOne);
        System.out.println("");
        
        double newWeightTwo = oneToTwo + learningCoeff * deltaHiddenTwo * inputTwo;
        System.out.printf("New Weights of 0.1: %.4f " , newWeightTwo);
        System.out.println("");
        
        double newWeightThree = twoToOne + learningCoeff * deltaHiddenOne * inputOne;
        System.out.printf("New Weights of 0.1: %.4f " , newWeightThree);
        System.out.println("");
        
        double newWeightFour = twoToTwo + learningCoeff * deltaHiddenTwo * inputTwo;
        System.out.printf("New Weights of 0.1: %.4f " , newWeightFour);
        System.out.println("");
        System.out.println("");
        
        System.out.println("After Multiple rounds");
        System.out.println("Input & hidden layer connection weights are constant");
        System.out.println("Hidden & output layers change over time");
        System.out.println("");
        
        double newHiddenOneToOne = 1.301;
        double newHiddenTwoToOne = 3.111;
        
        System.out.println("newHiddenOneToOne = 1.301");
        System.out.println("newHiddenTwoToOne = 3.111");
        System.out.println("");
        
        double newResultOne = inputOneOne*oneToOne + inputOneTwo*twoToOne;
        System.out.println("Net_Hidden_unit_1: 0*0.1 + 0*0.2 = " + newResultOne );
        
        double newResultTwo = inputOneOne*oneToTwo + inputOneTwo*twoToTwo;
        System.out.println("Net_Hidden_unit_2: 0*0.3 + 0*0.4 = " + newResultTwo );
        System.out.println("");
        
        double newOutputHiddenUnitOne = 1/(1 + Math.exp(-0));
        System.out.println("Output_of_hidden_unit_1: 1/(1+e^-(0)) = " + newOutputHiddenUnitOne);
        
        double newOutputHiddenUnitTwo = 1/(1 + Math.exp(-0));
        System.out.println("Output_of_hidden_unit_2: 1/(1+e^-(0)) = " + newOutputHiddenUnitTwo);
        System.out.println("");
        System.out.println("");
        
        double newNetWeight = OutputHiddenUnitOne * newHiddenOneToOne + OutputHiddenUnitTwo * newHiddenTwoToOne;
        System.out.println("Net_of_Output_unit_1: " + newNetWeight);
        System.out.println("");
        
        double newActualOutputUnitOne = 1/(1 + Math.exp(-newNetWeight));
        System.out.printf("Actual_Output_of_Output_unit_1: 1/(1+e^(2.206)) = %.4f" , newActualOutputUnitOne);
        System.out.println("");
        System.out.println("Actual output of output unit 1 is larger than 0.9, so we can accept it as 1");
        System.out.println("");
        
        double NewDeltaOutputUnitOne = (1 - newActualOutputUnitOne) * newActualOutputUnitOne * (1-newActualOutputUnitOne);
        System.out.printf("Delta_of_output_unit_1 = %.5f" , NewDeltaOutputUnitOne);
        System.out.println("");
        System.out.println("");
        
        System.out.println("New updated weights");
        
        double newUpdatedWeightOne = newHiddenOneToOne + learningCoeff * (NewDeltaOutputUnitOne) * OutputHiddenUnitOne;
        System.out.printf("New weights for 0.5 = %.4f" , newUpdatedWeightOne);
        System.out.println("");
        
        double newUpdatedWeightTwo = newHiddenTwoToOne + learningCoeff * (NewDeltaOutputUnitOne) * OutputHiddenUnitTwo;
        System.out.printf("New weights for 0.6 = %.4f" , newUpdatedWeightTwo);
        System.out.println("");
        System.out.println("");
        
        System.out.println("New weights between input and hidden layers");
        System.out.println("");
        
        
        double newDeltaHiddenOne = NewDeltaOutputUnitOne * newHiddenOneToOne * OutputHiddenUnitOne * (1 - OutputHiddenUnitOne);
        System.out.printf("Delta_hidden_unit_1 = %.5f " , newDeltaHiddenOne);
        System.out.println("");
        
        double newDeltaHiddenTwo = NewDeltaOutputUnitOne * newHiddenTwoToOne * OutputHiddenUnitTwo * (1 - OutputHiddenUnitTwo);
        System.out.printf("Delta_hidden_unit_2 = %.5f " , newDeltaHiddenTwo);
        System.out.println("");
        System.out.println("");
        
        double NewWeightOne = oneToOne + learningCoeff * newDeltaHiddenOne * inputOne;
        System.out.printf("New Weights of 0.1: %.4f " , NewWeightOne);
        System.out.println("");
        
        double NewWeightTwo = oneToTwo + learningCoeff * newDeltaHiddenTwo * inputTwo;
        System.out.printf("New Weights of 0.1: %.4f " , NewWeightTwo);
        System.out.println("");
        
        double NewWeightThree = twoToOne + learningCoeff * newDeltaHiddenOne * inputOne;
        System.out.printf("New Weights of 0.1: %.4f " , NewWeightThree);
        System.out.println("");
        
        double NewWeightFour = twoToTwo + learningCoeff * newDeltaHiddenTwo * inputTwo;
        System.out.printf("New Weights of 0.1: %.4f " , NewWeightFour);
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        
        System.out.println("Simlating using 2 inputs, 3 hidden units, and 1 output unit");
        System.out.println("Input (1,1) target output (1) results:");
        System.out.println("");
        
        double oneToOneA = 0.8;
        double oneToTwoB = 0.5;
        double oneToThreeC = 0.7;
        double twoToOneD = 0.6;
        double twoToTwoF = 0.4;
        double twoToThreeG = 0.9;
        
        double hiddenOneToOneA = 0.962;
        double hiddenTwoToOneB = 0.898;
        double hiddenThreeToOneC = 0.988;
        
        double DifflearningCoeff = 0.4;
        System.out.println("");
        
        double NewResultOne = inputFourOne*oneToOneA + inputFourTwo*twoToOneD;
        System.out.println("Net_Hidden_unit_1: 1*0.8 + 1*0.6 = " + NewResultOne );
        
        double NewResultTwo = inputFourOne*oneToTwoB + inputFourTwo*twoToTwoF;
        System.out.println("Net_Hidden_unit_2: 0*0.3 + 0*0.4 = " + NewResultTwo );
        
        double NewResultThree = inputFourOne*oneToThreeC + inputFourTwo*twoToThreeG;
        System.out.println("Net_Hidden_unit_3: 1*0.7 + 1*0.9 = " + NewResultThree);
        System.out.println("");
        
        double NewOutputHiddenUnitOne = 1/(1 + Math.exp(-1.4));
        System.out.printf("Output_of_hidden_unit_1: 1/(1+e^-(0)) = %.3f " , NewOutputHiddenUnitOne);
        System.out.println("");
        
        double NewOutputHiddenUnitTwo = 1/(1 + Math.exp(-0.9));
        System.out.printf("Output_of_hidden_unit_2: 1/(1+e^-(0)) = %.3f" , NewOutputHiddenUnitTwo);
        System.out.println("");
        
        double NewOutputHiddenUnitThree = 1/(1 + Math.exp(-1.6));
        System.out.printf("Output_of_hidden_unit_2: 1/(1+e^-(0)) = %.3f" , NewOutputHiddenUnitThree);
        System.out.println("");
        System.out.println("");
        
        double NetWeight = NewOutputHiddenUnitOne * hiddenOneToOneA + NewOutputHiddenUnitTwo * hiddenTwoToOneB + NewOutputHiddenUnitThree * hiddenThreeToOneC ;
        System.out.printf("Net_of_Output_unit_1: %.4f" , NetWeight);
        System.out.println("");
        System.out.println("");
        
        double NewActualOutputUnitOne = 1/(1 + Math.exp(-NetWeight));
        System.out.printf("Actual_Output_of_Output_unit_1: 1/(1+e^-(0.55)) = %.4f" , NewActualOutputUnitOne);
        System.out.println("");
        System.out.println("Actual output of output unit 1 is larger than 0.9, so we can accept it as 1");

        
        
        double NewDeltaOutputUnitOneA = (1 - NewActualOutputUnitOne) * NewActualOutputUnitOne * (1-NewActualOutputUnitOne);
        System.out.println("");
        System.out.printf("Delta_of_output_unit_1 = %.5f" , NewDeltaOutputUnitOneA);
        System.out.println("");
        System.out.println("");
        
        System.out.println("New updated weights");
        
        double NewUpdatedWeightOne = hiddenOneToOneA + DifflearningCoeff * (NewDeltaOutputUnitOneA) * NewOutputHiddenUnitOne;
        System.out.printf("New weights for 0.5 = %.4f" , NewUpdatedWeightOne);
        System.out.println("");
        
        double NewUpdatedWeightTwo = hiddenTwoToOneB + DifflearningCoeff * (NewDeltaOutputUnitOneA) * NewOutputHiddenUnitTwo;
        System.out.printf("New weights for 0.6 = %.4f" , NewUpdatedWeightTwo);
        System.out.println("");
        
        double NewUpdatedWeightThree = hiddenThreeToOneC + DifflearningCoeff * (NewDeltaOutputUnitOneA) * NewOutputHiddenUnitThree;
        System.out.printf("New weights for 0.6 = %.4f" , NewUpdatedWeightThree);
        System.out.println("");
        System.out.println("");
        
        System.out.println("New weights between input and hidden layers");
        System.out.println("");
        
        double NewDeltaHiddenOne = NewDeltaOutputUnitOneA * hiddenOneToOneA * NewOutputHiddenUnitOne * (1 - NewOutputHiddenUnitOne);
        System.out.printf("Delta_hidden_unit_1 = %.5f " , NewDeltaHiddenOne);
        System.out.println("");
        
        double NewDeltaHiddenTwo = NewDeltaOutputUnitOneA * hiddenTwoToOneB * NewOutputHiddenUnitTwo * (1 - NewOutputHiddenUnitTwo);
        System.out.printf("Delta_hidden_unit_2 = %.5f " , NewDeltaHiddenTwo);
        System.out.println("");
        
        double NewDeltaHiddenThree = NewDeltaOutputUnitOneA * hiddenThreeToOneC * NewOutputHiddenUnitThree * (1 - NewOutputHiddenUnitThree);
        System.out.printf("Delta_hidden_unit_3 = %.5f " , NewDeltaHiddenThree);
        System.out.println("");
        System.out.println("");
        
        
        double NewWeightOneA = oneToOneA + learningCoeff * NewDeltaHiddenOne * inputFourOne;
        System.out.printf("New Weights of 0.8: %.4f " , NewWeightOneA);
        System.out.println("");
        
        double NewWeightTwoB = oneToTwoB + learningCoeff * NewDeltaHiddenTwo * inputFourTwo;
        System.out.printf("New Weights of 0.5: %.5f " , NewWeightTwoB);
        System.out.println("");
        
        double NewWeightThreeC = oneToThreeC + learningCoeff * NewDeltaHiddenThree * inputFourOne;
        System.out.printf("New Weights of 0.7: %.5f " , NewWeightThreeC);
        System.out.println("");
        
        double NewWeightFourD = twoToOneD + learningCoeff * NewDeltaHiddenOne * inputFourTwo;
        System.out.printf("New Weights of 0.6: %.5f " , NewWeightFourD);
        System.out.println("");
        
        double NewWeightFourF = twoToTwoF + learningCoeff * NewDeltaHiddenTwo * inputFourOne;
        System.out.printf("New Weights of 0.4: %.5f " , NewWeightFourF);
        System.out.println("");
        
        double NewWeightFourG = twoToThreeG + learningCoeff * NewDeltaHiddenThree * inputFourTwo;
        System.out.printf("New Weights of 0.9: %.5f " , NewWeightFourG);
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        
        System.out.println("Simlating using 2 inputs, 3 hidden units, and 2 output unit");
        System.out.println("Input (1,1) target output (1,1) results:");
        System.out.println("");
        System.out.println("");
        
        
        
        double oneToOneAA = 0.6;
        double oneToTwoAB = 0.7;
        double oneToThreeAC = 0.9;
        double twoToOneAD = 0.4;
        double twoToTwoAF = 0.59;
        double twoToThreeAG = 0.34;
        
        double hiddenOneToOneAA = 0.991;
        double hiddenOneToTwoAB = 0.999;
        double hiddenTwoToOneAC = 0.989;
        double hiddenTwoToTwoAA = 0.887;
        double hiddenThreeToOneAB = 0.974;
        double hiddenThreeToTwoAC = 0.995;
        
        double DifflearningCoeffA = 0.9;
        System.out.println("");
        
        double NewResultOneA = inputFourOne*oneToOneAA + inputFourTwo*twoToOneAD;
        System.out.println("Net_Hidden_unit_1: 1*0.8 + 1*0.6 = " + NewResultOneA );
        
        double NewResultTwoB = inputFourOne*oneToTwoAB + inputFourTwo*twoToTwoAF;
        System.out.println("Net_Hidden_unit_2: 0*0.3 + 0*0.4 = " + NewResultTwoB );
        
        double NewResultThreeC = inputFourOne*oneToThreeAC + inputFourTwo*twoToThreeAG;
        System.out.println("Net_Hidden_unit_3: 1*0.7 + 1*0.9 = " + NewResultThreeC);
        System.out.println("");
        System.out.println("");
        
        
        double NewOutputHiddenUnitOneA = 1/(1 + Math.exp(-NewResultOneA));
        System.out.printf("Output_of_hidden_unit_1: 1/(1+e^-(0)) = %.4f " , NewOutputHiddenUnitOneA);
        System.out.println("");
        
        double NewOutputHiddenUnitTwoB = 1/(1 + Math.exp(-NewResultTwoB));
        System.out.printf("Output_of_hidden_unit_2: 1/(1+e^-(0)) = %.4f" , NewOutputHiddenUnitTwoB);
        System.out.println("");
        
        double NewOutputHiddenUnitThreeC = 1/(1 + Math.exp(-NewResultThreeC));
        System.out.printf("Output_of_hidden_unit_2: 1/(1+e^-(0)) = %.4f" , NewOutputHiddenUnitThreeC);
        System.out.println("");
        System.out.println("");
        
        double NewNetWeightA = NewOutputHiddenUnitOneA * hiddenOneToOneAA + NewOutputHiddenUnitTwoB * hiddenTwoToOneAC + NewOutputHiddenUnitThreeC * hiddenThreeToOneAB;
        System.out.printf("Net_of_Output_unit_1: %.4f" , NewNetWeightA);
        System.out.println("");
        
        double NewNetWeightB = NewOutputHiddenUnitOneA * hiddenOneToTwoAB + NewOutputHiddenUnitTwoB * hiddenTwoToTwoAA + NewOutputHiddenUnitThreeC *hiddenThreeToTwoAC ;
        System.out.printf("Net_of_Output_unit_2: %.4f" , NewNetWeightB);
        System.out.println("");
        System.out.println("");
        
        
        double NewActualOutputUnitOneA = 1/(1 + Math.exp(-NewNetWeightA));
        System.out.printf("Actual_Output_of_Output_unit_1: 1/(1+e^-(2.2554)) = %.4f" , NewActualOutputUnitOneA);
        System.out.println("");
        System.out.println("Actual output of output unit 1 is larger than 0.9, so we can accept it as 1");
        System.out.println("");
        
        
        double NewActualOutputUnitOneAB = 1/(1 + Math.exp(-NewNetWeightB));
        System.out.printf("Actual_Output_of_Output_unit_1: 1/(1+e^-(2.1976)) = %.4f" , NewActualOutputUnitOneAB);
        System.out.println("");
        System.out.println("Actual output of output unit 1 is larger than 0.9, so we can accept it as 1");
        System.out.println("");

        double NewDeltaOutputUnitOneAB = (1 - NewActualOutputUnitOneA) * NewActualOutputUnitOneA * (1-NewActualOutputUnitOneA);
        System.out.println("");
        System.out.printf("Delta_of_output_unit_1 = %.5f" , NewDeltaOutputUnitOneAB);
        
        double NewDeltaOutputUnitOneAC = (1 - NewActualOutputUnitOneAB) * NewActualOutputUnitOneAB * (1-NewActualOutputUnitOneAB);
        System.out.println("");
        System.out.printf("Delta_of_output_unit_2 = %.5f" , NewDeltaOutputUnitOneAC);
        System.out.println("");
        System.out.println("");
        
        
        System.out.println("New updated weights");
        System.out.println("");
        
        double NewUpdatedWeightOneA = hiddenOneToOneAA + DifflearningCoeffA * (NewDeltaOutputUnitOneAB) * NewOutputHiddenUnitOneA;
        System.out.printf("New weights for 0.991 = %.4f" , NewUpdatedWeightOneA);
        System.out.println("");
        
        double NewUpdatedWeightTwoB = hiddenTwoToOneAC + DifflearningCoeffA * (NewDeltaOutputUnitOneAB) * NewOutputHiddenUnitTwoB;
        System.out.printf("New weights for 0.999 = %.4f" , NewUpdatedWeightTwoB);
        System.out.println("");
        
        double NewUpdatedWeightThreeC = hiddenThreeToOneAB + DifflearningCoeffA * (NewDeltaOutputUnitOneAB) * NewOutputHiddenUnitThreeC;
        System.out.printf("New weights for 0.989 = %.4f" , NewUpdatedWeightThreeC);
        System.out.println("");
        
        
        
        double NewUpdatedWeightOneAA = hiddenOneToTwoAB + DifflearningCoeffA * (NewDeltaOutputUnitOneAC) * NewOutputHiddenUnitOneA;
        System.out.printf("New weights for 0.887 = %.4f" , NewUpdatedWeightOneAA);
        System.out.println("");
        
        double NewUpdatedWeightTwoAB = hiddenTwoToTwoAA + DifflearningCoeffA * (NewDeltaOutputUnitOneAC) * NewOutputHiddenUnitTwoB;
        System.out.printf("New weights for 0.974 = %.4f" , NewUpdatedWeightTwoAB);
        System.out.println("");
        
        double NewUpdatedWeightThreeAC = hiddenThreeToTwoAC + DifflearningCoeffA * (NewDeltaOutputUnitOneAC) * NewOutputHiddenUnitThreeC;
        System.out.printf("New weights for 0.995 = %.4f" , NewUpdatedWeightThreeAC);
        System.out.println("");
        System.out.println("");        
        
        
        System.out.println("New weights between input and hidden layers");
        System.out.println("");
        
        
        double NewDeltaHiddenOneA = NewDeltaOutputUnitOneAB * hiddenOneToOneAA * NewOutputHiddenUnitOneA * (1 - NewOutputHiddenUnitOneA);
        System.out.printf("Delta_hidden_unit_1 = %.5f " , NewDeltaHiddenOneA);
        System.out.println("");
        
        double NewDeltaHiddenTwoB = NewDeltaOutputUnitOneAB * hiddenOneToTwoAB * NewDeltaOutputUnitOneAB * (1 - NewDeltaOutputUnitOneAB);
        System.out.printf("Delta_hidden_unit_2 = %.5f " , NewDeltaHiddenTwoB);
        System.out.println("");
        
        double NewDeltaHiddenThreeC = NewDeltaOutputUnitOneAC * hiddenTwoToOneAC * NewOutputHiddenUnitThreeC * (1 - NewOutputHiddenUnitThreeC);
        System.out.printf("Delta_hidden_unit_3 = %.5f " , NewDeltaHiddenThreeC);
        System.out.println("");
        
        double NewDeltaHiddenOneAA = NewDeltaOutputUnitOneAB * hiddenThreeToOneAB * NewOutputHiddenUnitOneA * (1 - NewOutputHiddenUnitOneA);
        System.out.printf("Delta_hidden_unit_4 = %.5f " , NewDeltaHiddenOneAA);
        System.out.println("");
        
        double NewDeltaHiddenTwoAB = NewDeltaOutputUnitOneAC * hiddenTwoToTwoAA * NewDeltaOutputUnitOneAC * (1 - NewDeltaOutputUnitOneAC);
        System.out.printf("Delta_hidden_unit_5 = %.5f " , NewDeltaHiddenTwoAB);
        System.out.println("");
        
        double NewDeltaHiddenThreeAC = NewDeltaOutputUnitOneAC * hiddenThreeToTwoAC * NewOutputHiddenUnitThreeC * (1 - NewOutputHiddenUnitThreeC);
        System.out.printf("Delta_hidden_unit_6 = %.5f " , NewDeltaHiddenThreeAC);
        System.out.println("");
        System.out.println("");
        
        
        double NewWeightOneAA = oneToOneAA + DifflearningCoeffA * NewDeltaHiddenOneA * inputFourOne;
        System.out.printf("New Weights of 0.6: %.4f " , NewWeightOneAA);
        System.out.println("");
        
        double NewWeightTwoAB = oneToTwoAB + DifflearningCoeffA * NewDeltaHiddenTwoB * inputFourTwo;
        System.out.printf("New Weights of 0.7: %.5f " , NewWeightTwoAB);
        System.out.println("");
        
        double NewWeightThreeAC = oneToThreeAC + DifflearningCoeffA * NewDeltaHiddenThreeC * inputFourOne;
        System.out.printf("New Weights of 0.9: %.5f " , NewWeightThreeAC);
        System.out.println("");
        
        double NewWeightFourAD = twoToOneAD + DifflearningCoeffA * NewDeltaHiddenOneAA * inputFourTwo;
        System.out.printf("New Weights of 0.4: %.5f " , NewWeightFourAD);
        System.out.println("");
        
        double NewWeightFourAF = twoToTwoAF + DifflearningCoeffA * NewDeltaHiddenTwoAB * inputFourOne;
        System.out.printf("New Weights of 0.59: %.5f " , NewWeightFourAF);
        System.out.println("");
        
        double NewWeightFourAG = twoToThreeAG + DifflearningCoeffA * NewDeltaHiddenThreeAC * inputFourTwo;
        System.out.printf("New Weights of 0.34: %.5f " , NewWeightFourAG);
        System.out.println("");
        System.out.println("");



        
    }
    private void sigmoidFunction(){
        double OutputHiddenUnitOne = 1/(1 + Math.exp(-0));
    }
    
}
