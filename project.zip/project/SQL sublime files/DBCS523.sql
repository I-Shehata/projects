drop TABLE customer;
drop table currency cascade constraints;
drop TABLE company;
drop TABLE country;
drop TABLE transferRate;
drop TABLE transaction;

CREATE TABLE customer
(
	cus_id VARCHAR(20),
	cus_name VARCHAR(40),
	cus_address VARCHAR(40),
	cus_age VARCHAR(10),
	cus_location VARCHAR(40),
	PRIMARY KEY (cus_id)
);

CREATE TABLE currency
(
	curr_id VARCHAR(20),
	curr_name VARCHAR(30),
	curr_origin VARCHAR(20),
	curr_location VARCHAR(40),
	curr_destination VARCHAR(40),
	PRIMARY KEY (curr_id)
);

CREATE TABLE company
(
	com_id VARCHAR(20),
	curr_id VARCHAR(20),
	com_name VARCHAR(20),
	com_address VARCHAR(20),
	trans_amount VARCHAR(40),
	PRIMARY KEY (com_id, curr_id),
	foreign key (curr_id) references currency
		on delete cascade
);

CREATE TABLE country
(
	count_id VARCHAR(20),
	count_name VARCHAR (40),
	count_curr VARCHAR(40),
	curr_id VARCHAR(40),
	PRIMARY KEY (count_id),
	foreign key (curr_id) references currency
		on delete cascade
);

CREATE TABLE transferRate
(
	tr_id VARCHAR(20),
	curr_id VARCHAR(20),
	funds VARCHAR(40),
	TransRate VARCHAR(10),
	PRIMARY KEY (tr_id, curr_id),
	foreign key (curr_id) references currency
		on delete cascade
);

CREATE TABLE transaction
(
	trans_id VARCHAR(30),
	curr_id VARCHAR(20),
	trans_amount VARCHAR(30),
	trans_day VARCHAR(20),
	trans_month VARCHAR(20),
	trans_year VARCHAR(20),
	PRIMARY KEY (trans_id, curr_id),
	foreign key (curr_id) references currency
		on delete cascade
);